//Dummy JS as example to work with on Gulp.js

var max = 10;
for(var z = 0; z < max; z++){
    console.log(z);
}